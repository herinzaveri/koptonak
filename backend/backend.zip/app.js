const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const multer = require("multer");
const path = require("path");
const Data = require("./model/data");
const Category = require("./model/category");

const app = express();

app.use(express.json());
app.use(cors());
app.use(methodOverride("_method"));
app.use(express.static(__dirname + "/public"));

const mongoURI = "mongodb+srv://herin-chaitanya:herin-chaitanya@cluster0.6pkzs.mongodb.net/espresso?retryWrites=true&w=majority";
// connection
let conn;

const connectFunction = async () => {
	conn = await mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true });
};

connectFunction();

// routes
app.use("/", require("./routes/index"));

// set storage engine
const storage = multer.diskStorage({
	destination: "./public/uploads/",
	filename: function (req, file, cb) {
		cb(null, Date.now() + path.extname(file.originalname));
	},
});

// init upload
const upload = multer({
	storage: storage,
}).single("image");

// to upload image
app.post("/upload", (req, res) => {
	upload(req, res, err => {
		if (err) {
			console.log(err);
			res.status(400).send({
				message: "oops something went wrong...",
			});
		} else {
			res.status(200).send({
				path: "uploads/" + req.file.filename,
			});
		}
	});
});

// to upload post data
app.post("/data", async (req, res) => {
	let data = new Data(req.body);

	data = await data.save();

	res.send(data);
});

// to get all images
app.get("/images", async (req, res) => {
	const images = await Data.find({ isApproved: true });

	res.send(images);
});

// to get pending images
app.get("/pending", async (req, res) => {
	const images = await Data.find({ isApproved: false });

	res.send(images);
});

// to approve image
app.put("/approve", async (req, res) => {
	let response = await Data.findByIdAndUpdate(req.body.id, { isApproved: true });

	res.send(response);
});

// to delete a post
app.delete("/data/:id", async (req, res) => {
	let response = await Data.findByIdAndDelete(req.params.id);

	res.send(response);
});

// to check if url exist
app.post("/image", async (req, res) => {
	let domain = new URL(req.body.url);
	let url = domain.hostname;

	let regex = new RegExp(url);
	let response = await Data.findOne({ url: { $regex: regex, $options: "i" } });

	if (response) {
		res.send({
			exist: true,
		});
	} else {
		res.send({
			exist: false,
		});
	}
});

// to upload a category
app.post("/category", async (req, res) => {
	let categoryName = req.body.name;

	const categoryExist = await Category.find({ categoryName: categoryName });

	if (categoryExist.length > 0) {
		res.status(200).send({
			status: 400,
			message: "This category already exist",
		});
	} else {
		let category = new Category({ categoryName: categoryName });
		category = await category.save();

		res.status(200).send({
			status: 200,
			message: "Category added successfully",
		});
	}
});

// to edit category
app.put("/category", async (req, res) => {
	let categoryName = req.body.name;

	const categoryExist = await Category.find({ categoryName: categoryName });

	if (categoryExist.length > 0) {
		res.status(200).send({
			status: 400,
			message: "This category already exist",
		});
	} else {
		let id = req.body.id;
		let previousCategory = await Category.findById(id);
		let category = await Category.findByIdAndUpdate(id, { categoryName: categoryName });

		previousCategory = previousCategory.categoryName;

		updateCategoryInData(previousCategory, categoryName);

		res.status(200).send({
			status: 200,
			message: "Category updated successfully",
		});
	}
});

// update category in data function
const updateCategoryInData = async (previousCategory, categoryName) => {
	await Data.updateMany({ category: { $eq: previousCategory } }, { category: categoryName });
};

// to get all category
app.get("/categories", async (req, res) => {
	const categories = await Category.find();

	res.send(categories);
});

// to get specific category
app.get("/category/:id", async (req, res) => {
	const category = await Category.findById(req.params.id);

	res.send(category);
});

// to delete category
app.delete("/category/:id", async (req, res) => {
	const reponse = await Category.findByIdAndDelete(req.params.id);

	res.send();
});

// to delete a post
app.delete("/post/:id", async (req, res) => {
	const reponse = await Data.findByIdAndDelete(req.params.id);

	res.send();
});

// to edit a post
app.put("/post", async (req, res) => {
	const { englishName, arabicName, url, category, email, description, isPinned } = req.body;
	let bodyObj = {
		englishName,
		arabicName,
		url,
		category,
		email,
		description,
		isPinned,
	};
	let post = await Data.findOneAndUpdate({ _id: req.body.id }, bodyObj);

	res.status(200).send({
		status: 200,
		message: "Post updated successfully",
	});
});

// to get specific post
app.get("/data/:id", async (req, res) => {
	let post = await Data.findById(req.params.id);

	res.send(post);
});

const port = 3000;

app.listen(port, () => console.log(`listening on port ${port}...`));
