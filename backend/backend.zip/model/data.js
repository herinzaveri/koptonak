const mongoose = require("mongoose");

const dataSchema = mongoose.Schema({
	arabicName: {
		type: String,
	},
	englishName: {
		type: String,
	},
	url: {
		type: String,
	},
	category: {
		type: String,
	},
	imagePath: {
		type: String,
	},
	email: {
		type: String,
	},
	description: {
		type: String,
	},
	isApproved: {
		type: Boolean,
		default: false,
	},
	isPinned: {
		type: Boolean,
		default: false,
	},
});

const Data = mongoose.model("datas", dataSchema);

module.exports = Data;
